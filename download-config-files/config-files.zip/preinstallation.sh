sudo apt-get install ufw

sudo cd /home/pi/newcluster

sudo chmod +x ./setup.sh 

sudo reboot
